package com.example.spisokludei;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPersonName;
    private ListView listView;
    private ArrayList<String> groupMembers = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPersonName = findViewById(R.id.editTextPersonName);
        listView = findViewById(R.id.listView);
        Button buttonAdd = findViewById(R.id.buttonAdd);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, groupMembers);
        listView.setAdapter(adapter);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newName = editTextPersonName.getText().toString();
                if (!newName.isEmpty()) {
                    groupMembers.add(newName);
                    adapter.notifyDataSetChanged();
                    editTextPersonName.setText(""); // Clear the input for the next entry
                    editTextPersonName.clearFocus(); // Remove focus from EditText
                }
            }
        });

        listView.setOnItemClickListener((adapterView, view, position, id) -> {
            final EditText editTextInput = new EditText(MainActivity.this);
            editTextInput.setText(groupMembers.get(position));

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Edit Name");
            builder.setView(editTextInput);

            builder.setPositiveButton("OK", null);
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

            AlertDialog dialog = builder.create();

            dialog.setOnShowListener(dialogInterface -> {
                Button okButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                okButton.setOnClickListener(view1 -> {
                    String editedName = editTextInput.getText().toString();
                    if (!editedName.isEmpty()) {
                        groupMembers.set(position, editedName);
                        adapter.notifyDataSetChanged();
                        dialog.dismiss();
                    } else {
                        editTextInput.setError("Name cannot be empty");
                    }
                });
            });

            dialog.show();
        });



    }
}
